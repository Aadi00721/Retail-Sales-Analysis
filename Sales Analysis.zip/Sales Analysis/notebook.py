a = int(input("Enter a number"))
if a%2==0:
    print("It is even")
else:
    print("odd")  